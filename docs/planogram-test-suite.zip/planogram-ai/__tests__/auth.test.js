import { describe, it, expect } from 'vitest'

describe('Auth Checks', () => {
  it('should fake login success', () => {
    const user = { email: 'test@example.com' }
    expect(user.email).toContain('@')
  })
})
